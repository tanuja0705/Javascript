//1. array in litral syntax
let arr1=[1,2,'three',false];

//2. array constructor
let arr2= new Array(1,'two',3);

//3. using Array.of()
let arr3 = Array.of(1,2,3,'four');

console.log("Arr1:"+ arr1);
console.log("Arr2:"+ arr2);
console.log("Arr3:"+ arr3);

//to print the type of array
console.log(typeof(arr1));

//to print the length of array
console.log(arr1.length);

//accessing element of a specific index
console.log(arr1[1]);

//1. toString(): to conver the array into string, the toString() method of an array converts all array elements into a single string.
//Each element is converted to a string
//Elements are joined with commas ( , ) by default

console.log(arr1.toString());
//checking its type
console.log(typeof(arr1.toString()));

//2. join(speratorb): to join the elements of an array as a single entity we use join method, where we will call this
//method with the array refrence variable and in the join method we have to pass an argument so by that argumnet
// it will seprate the elements of the array into a single string, if we are not passing any argument in 
//join method it will seprate the string by default by a coma','
// return type is String
console.log("join");
var arr=[1,2,4.5,'hii'];
console.log(arr);
// to print the index
// for(let a in arr){
//     console.log(a);
// }
console.log(arr.join(""));

//3.push(value): to add element in an array, push() always adds the element at the end of the array.
//The push() method in JavaScript returns a number.
//Specifically, it returns the new length of the array after adding the element(s).
//While adding we can add multiple elements at a time

let a=[11,22,33];
console.log("original length:"+ a.length);
console.log(a);
a.push(44);
console.log("updated length:"+ a.length);
console.log(a);
a.push("hiii",12,'bye');

//4. pop(): to remove the last element from array
//The pop() method in JavaScript returns the element that was removed from the array.
//While removing we can only remove one element
console.log("Removed:"+ a.pop());


//5. unshift(value): to add element at the beginning of the array
//unshift return type is length of the new array
a=[2,3,4];
console.log("Before shifting");
console.log(a);

a.unshift(1);

console.log("After shifting");
console.log(a);


//6. shift(): to remove the 1st element from the array
//shift method will return the removed array
console.log("Removed 1st element:"+ a.shift());


//7. concat(): use to add/merge more than one array 
// It will not affect the original array it will be returning a new array
// We can even pass the value in concat method
let a1=[1,2];
let a2=[6];
let a3=[3,4];

console.log(a1.concat(a3,5,a2));
console.log(a1);
a4=a1.concat(a3,5,a2);
console.log(a4);

//8. slice(start index,end endindex) in end index whatever value we will give it will take the element as
//endindex-1
const num=[1,2,3,4,5,6];
num2=num.slice(2,5);
console.log(num2);

//9. splice(): to add remove replace the element in an array
//syntax: array.splice(start index,delete count,new ele1,new ele2,...,new elen);
// It will affect the orignal array
// If we are deleteing anything it will return the deleted value
// For deleting if we pass more count so it will start deleting from the given start index till the delete
//count is done
let array=[1,2,"India",'Mango',2,34.5,12,true];
console.log("Before deleting:"+ array);

//deleting element
array.splice(4,2);
console.log("After deleting:"+ array);

//adding element
array.splice(2,0,"Watermelone", "banana");
console.log("After adding element in 2nd indec:"+ array);

//10. Sort(): to sort the array , it will affect the array
// for string & character it will start soring from a to z means whatever comes from a will be given sorted
//1st n then other alphabet, if 1st alphabet is same then with next alphabet
let s=['d','e','abc','a','s','bc','h','b','ac','badd'];
s.sort();
console.log("Sort:"+s);

//Here sorting the number it will sort them with single digit of each number and if the 1st digit is same
//then with the next digit
let s1=[234,12345,17,34];
//s1.sort();
console.log(s1);

// so to avoid this number issue we go for comparision

let comparisionFun=(a,b)=>{return a-b};
s1.sort(comparisionFun);
console.log(s1);

//11. indexOf(element): it will return the index of the specified element, if we have multiple elements 
//then it will return the 1st index of where the element is found
// if we are searching index of an element which is not present in the array then it will return -1
let index=[1,4,7,23,1,2,5,7,10];
console.log(index.indexOf(7));

//12. lastIndexOf(element): It will return the last accurance of that element in the array
console.log(index.lastIndexOf(7));

//13. reverse(): It will reverse the entire array 1st to last last to 1st, 2nd to 2nd last 2nd last to 2
//etc
let rev=[1,4,7,23,[7,2]]
console.log(rev.reverse());


/*********************************** Method to iterate among the array **********************************/
//1. forEach(): It will iterate through each element in array n will perform the operation on each element
//of array
//syntax: forEach((element,index(optional),array(optional))=>{logic})
// it won't return anything n will not affect the actual array if we try to return any value and store in a 
//variable it will return undefined
console.log("Foreach");

let arrVal=[1,2,3,4];
arrVal.forEach((element) => {
    console.log(element+3); 
});

let name=["tanuja","sayali","saloni","sujata"];
name.forEach((ele,ind)=>{
    console.log(ind+" : "+ele);
});

//2. map(): It will be returning a new array after performing the operation specified
//it will bot affect the actual array
//syntax: let a=array.map((ele,u=index,array)=>{logic})
//console.log("Map:");

let numbers=[12,13,14,15];
let newNumber=numbers.map((ele)=>{
    console.log(ele+5);;
    return ele+5;
})
console.log(newNumber);

//3. reduce(call back function(a function inside another function)): it will accpet a call abck fuchtion
// which called as reduce function inside which logic to reduce the array into single value and the reduce 
//function will have some parameters(1. accumalater, current val,current index, array)
//syntax: redunce(accumalater,current val, current index(opt), array(opt)=>{},initial value)
//if we are not specifing initial value it will take the 1st argument of array
//for 1st itteration accumalater will have the value of 1st index and then it will have the updated action 
//we are doing in the oeration and current value will start with 2nd index and will always hold the next 
//element of the array 

console.log("Reduce:");

let red=[1,2,3,4];
let acc=red.reduce((a,b)=>{
    console.log(a+" "+b);
    return a*b});
console.log(acc); 

//maximum of array
let i=[1,4,7,23,143];
let max=i.reduce((a,b)=>{return a>b?a:b;
},);
console.log("Max in "+i+" is "+max);

//maximum of array
let j=[1,-4,7,23,143];
let min=j.reduce((a,b)=>{ return a<b?a:b;
},);
console.log("Min in "+j+" is "+ min);