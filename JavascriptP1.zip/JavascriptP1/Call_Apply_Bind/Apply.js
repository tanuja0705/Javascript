fullName= function (mname,age) {
        console.log(this.fname+" "+mname+" "+this.lname+" Age:"+age);
    }

let obj1={
    fname:"Tanuja",
    lname:"Sonawale",
}

let obj2={
    fname:"Abhijeet",
    lname:"Sonawale"
}

fullName.apply(obj1,["N",25]);
fullName.apply(obj2,["Nagnath",24]);
