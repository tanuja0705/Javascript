fullName= function (mname,age) {
        console.log(this.fname+" "+mname+" "+this.lname+" Age:"+age);
    }

let obj1={
    fname:"Tanuja",
    lname:"Sonawale",
}

let obj2={
    fname:"Abhijeet",
    lname:"Sonawale"
}

let fun1=fullName.bind(obj1,"N",25);
fun1();
let fun2=fullName.bind(obj2,"Nagnath",24);
fun2();