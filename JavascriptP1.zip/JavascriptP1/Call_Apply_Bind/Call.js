// let obj1={
//     fname:"Tanuja",
//     lname:"Sonawale",
//     fullName: function () {
//         console.log(this.fname+" "+this.lname);
//     }
// }

// let obj2={
//     fname:"Abhijeet",
//     lname:"Sonawale"
// }

// obj1.fullName();
// //call(refrenxe of this keyword) barrows method from one object(obj1) to other object(obj2)
// obj1.fullName.call(obj2);

// fullName= function () {
//         console.log(this.fname+" "+this.lname);
//     }

// let obj1={
//     fname:"Tanuja",
//     lname:"Sonawale",
// }

// let obj2={
//     fname:"Abhijeet",
//     lname:"Sonawale"
// }

// fullName.call(obj1);
// fullName.call(obj2);
//obj1.fullName.call(obj2);

fullName= function (mname,age) {
        console.log(this.fname+" "+mname+" "+this.lname+" Age:"+age);
    }

let obj1={
    fname:"Tanuja",
    lname:"Sonawale",
}

let obj2={
    fname:"Abhijeet",
    lname:"Sonawale"
}

fullName.call(obj1,"Nagnath",25);
fullName.call(obj2,"N",24);
