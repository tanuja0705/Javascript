let str = "Tanuja";
let str1= "        Sonawale   ";
let str2="deluludelulu";

//1. length of String
console.log(str.length);
console.log(str1.length);

//2. specific character from a string
console.log(str[2]);
console.log(str1[5]);

//3. everything in uppercase
console.log(str.toUpperCase());

//4. everything in lowercasex
console.log(str1.toLowerCase());

//5. slice:to print part of a string we use slice method it accepts 2 arguments 1st start point n 2nd end( where 
//end menas it is 4 the 4-1=3), if we don't give end index it will cut till end
console.log(str.slice(0,4));

//6. split: to divide a string syntax: string.split("seprator", max splits) if we don't give max split it 
// will split till the no. of seprators we have & it returns array if we are giving less splits then the remaing 
//word will also be removed
let arr= str2.split("u",3);
console.log(arr);

//7. trim: to remove the space which are at the start or end of the string not in between spaces
console.log("Original:"+str1);
console.log("Trimed:"+str1.trim());

//8. replace: to replace anything in a string only its 1st occurance will be replaced
console.log("Original:"+str);
console.log("Replaced:"+ str.replace("a","i"));
//if with replace we want to replace all the occurance of it then we should make the pare which we want to 
//replace as global
console.log("Replaced:"+ str.replace(/a/g,"i"));

//9. replaceAll: to replace all the alphabets or part of string what we want to replace throughout the 
//string
console.log("Original:"+str);
console.log("Original:"+str.replaceAll("a","i"));

//10.concat: join more than on string and returm a single string
let st1="Swati";
let st2="Nagnath";
let st3="Sonawale";
//st1=st1.concat(" ",st2.concat(" ",st3));
//st1=st1.concat(" ",st2," ",st3);
st1=st1+" "+st2+" "+st3
console.log(st1);


//template literals
let a="Byeee all";
//this combining the string directly with the variables is called as String interpolation
let b=`Hii all ${a}`;
console.log(b);

//Note: to declare a string we can use (""),(''),(``)

//11. include: to check whether the given string is included in it or not
//syntax: string.includes("substring", position from where to start the search(optional))
//indexing starts with 0 and the return type of this method is boolean, this method is case sensitive
let c="hello good morning";
console.log(c.includes("mor",11));

//12. charAt(): returns the character at the index which we will specify in the method paranthesis
//syntax: string.charAt(index), if the index that we pass is exceding the size of string then insted of 
//throwing exception it will print empty string

console.log(c.charAt(4));
console.log(c.charAt(25));

//13. indexOf(): It will return the index of the specified character in the arguements of that method
//syntax: string.indexOf(character,position from where it should start searching(opptional)) if the character which we are specifing is not present in the string it will return -1
//it will give the 1st occurance of the character's index
console.log(c.indexOf("o"));

//14. lastIndexOf(): it will give the last occurance index of the character, it is case sensitive
//if the character which we are specifing is not present in the string it will return -1
console.log(c.lastIndexOf('o'));

