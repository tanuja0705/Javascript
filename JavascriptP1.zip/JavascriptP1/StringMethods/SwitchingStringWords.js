
let msg="I love my India ss";
let msgs=msg.split(" ").reverse();
let newMsg="";
for(let m of msgs) {
    newMsg+=m+" ";
}
console.log("Actual:"+msg);
console.log("Reversed:"+newMsg);