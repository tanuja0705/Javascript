function add(a,b,fun1,fun2) {
    let c= a+b;
    fun1(a,b,fun2,c);
}
function sub(a,b,fun,sum) {
    let s= a-b;
    fun(sum,s)
}
function result(a,b) {
    console.log(`Addition result is:${a}`);
    console.log(`Substraction result is:${b}`);
}

add(10,5,sub,result);