function f1(fun) {
    fun();
    console.log("f1 function");
}
function f2() {
    console.log("f2 function"); 
}
f1(f2);

console.log("*******************************************************************************************");
f1(function f3() {
    console.log("f3 function");
})

console.log("*******************************************************************************************");
f1(()=>{console.log("f4 arrow function");
})

console.log("*******************************************************************************************");
function fun1(cb1,cb2) {
    cb1(cb2);
    console.log("fun1 function");
}

function fun2(cb) {
    cb();
    console.log("fun2 function");
} 

function fun3() {
    console.log("fun3 function");
}

fun1(fun2,fun3);