let order;
function placeOrder(food,m,m1) {
    console.log("Please plance an order");
    setTimeout(() => {
        order=food;
        m(m1);
    }, 3000);
    console.log("Thanks for ordering");
}
placeOrder("Biriyani",foodOrdered,review)
function foodOrdered(m) {
console.log(order);
m();
}

function review() {
    setTimeout(() => {
        console.log("Good");
    }, 3000);
}