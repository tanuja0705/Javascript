//register user
let promise1 = new Promise((pro,con)=>{
    console.log("In registration page");
    pro("User is registered successfully");
    con("Issue while registering user")
}).then((msg)=> {
    console.log(msg);
    //login
    let promise2 = new Promise((pro,con)=> {
        console.log("In login method");
        pro("User logged in");
        con("User logged out");
    }).then((msg)=>{
        console.log(msg);
        let promise3 = new Promise((pro,con)=> {
            console.log("In add to cart");
            pro("Added product to cart");
            con("issue while adding product to cart")
        }).then((msg)=> {
            return msg;
        }).catch((msg)=>{
            return msg;
        })
    }).catch((msg)=>{
        console.log(msg);       
    })
})
.catch((msg)=>{
    console.log(msg); 
})