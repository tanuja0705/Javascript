let products=['pen','pencil','book']
function wishlish(items) {
    let num=Math.random()*10000;
    setTimeout(() => {
       return num; 
    }, 3000);
}

let orderId=wishlish(products);
orderId.then(function proceedToPay(){
    console.log("Order placed");   
});
