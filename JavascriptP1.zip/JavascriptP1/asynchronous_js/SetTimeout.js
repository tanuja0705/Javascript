// if it is with respect to var it will take last updated value and print
console.log("************************************** var ****************************************");
for(var a=0;a<3;a++) {
    setTimeout(() => {
        console.log(a);
    }, 1000);
}
setTimeout(()=>{console.log("************************************** let ****************************************");
},2000)

//here as it is a let variable it will store the specific value of the variable in it when the function is 
//call by queue.
for(let a=0;a<3;a++) {
    setTimeout(() => {
        console.log(a);
    }, 3000);
}

setTimeout(()=>{console.log("************************************** const ****************************************");},3000)
const b=12;
    setTimeout(() => {
        console.log(b);
    }, 3000);