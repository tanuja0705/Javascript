function f1() {
    var a=10;
    var b=2;
    return function f2() {
        console.log(a+" "+b);
        console.log(a+b);
        a++;
        b++;
    }

    // return function f3() {
    //      console.log(a+" "+b);
    //      console.log(a-b);
    //       a++;
    //       b--;
    // }
}

var a=f1();
a();
a();
let a1=a;
console.log("*****");

a1();
a();
a();
 console.log("==========================================================================================");

var b=f1();
b();
b();
b();
// console.log("==========================================================================================");

// let c=f1()
// c();
// c();
// // a();
// // a();
// // a();