function f1(n1) {
    let age=25;
    console.log("Name:"+n1+" Age:"+age);
    function f2() {
        let city="Solapur";
        console.log("Name:"+n1+" Age:"+age+" City:"+city);
        let fMembers=function f3() {
            let famMem=4;
            return famMem;
        }
        return fMembers;
    }
    return f2();    
}

let n=f1("Tanuja");
console.log(n());