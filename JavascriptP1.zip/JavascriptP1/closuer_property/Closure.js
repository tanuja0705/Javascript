// function f1() {
//     let a=10;
//     let b=25;
//     function f2() {
//         console.log(a);
//         console.log(b);
        
//     }
//     f2();
// }
// f1();


function a1() {
    let num=30
    let num2=50
    function a2() {
        let num3=5
        console.log(num)
        console.log(num2)

        function a3() {
             console.log(num)
             console.log(num2)
             console.log(num3)
        }
        a3()
    }
    return a2
}

let fun=a1()
fun()
