a = 30;
b = 20;
//if else
    console.log("*********************if else***********************");
if(a<b) {
    console.log(a+" is smaller then "+b);
} else {
    console.log(b+" is smaller then "+a);
}

//if else if
console.log("***********************if else if***********************");
c=1;
if(a>b && a>c) {
    console.log(a+" is greater that "+b+" and "+c);  
} else if(b>a && b>c) {
    console.log(b+" is greater that "+a+" and "+c); 
} else console.log(c+" is greater that "+a+" and "+b); 

//Nested if else
console.log("********************Nested if else**********************");
if(a>b) {
    if(a>c) 
        console.log(a+" is greatest of all");
    else
        console.log(a+" is greater then "+b+" but smaller then "+c);
} else if(b>a) {
    if(b>c)
        console.log(b+" is greatest of all");
    else
        console.log(b+" is greater then "+a+" but smaller then "+c);      
} else if(c>a) {
    if(c>b)
        console.log(c+" is greatest of all");
    else
        console.log(c+" is greater then "+a+" but less then "+b);   
} else if(a==b && b==c)
    console.log("ALl the number are same");
