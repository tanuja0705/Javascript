let date=1+6;
switch (date) {
    case 1:
        console.log("Abhi and Pappa");
        break;
    case 8:
        console.log("My");
        break;
        
    case 16:
        console.log("Maaa n Richa");
        break;

    case 7:
        console.log("Anmol");
        break;

    case 3:
        console.log("Ruttaaaaaaaa");
        break;
        
    case 26:
        console.log("Suppp");
        break;
        
}