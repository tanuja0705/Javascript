let str1="Salman";
let str2="Salman";
str1===str2?console.log(str1+" and "+str2+" are same words"):console.log(str1+" and "+str2+" are not same words");
