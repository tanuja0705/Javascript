// changes made in one variable will not effect in other value & it is 
//immutable bcz for a one memory is assigned and for b one memory is assigned
//Premitive datatype
let a=10;
let b=a;
console.log(a);
console.log(b);
b=40;
console.log(a);
console.log(b);

//Premitive datatypes
//1. String
let s1="Anmol"; //s1='Anmol'
console.log("Type of data:"+ typeof(s1));
let stringObj=new String(s1);
console.log("Type of data:"+ typeof(stringObj));

//2.number
let num=7;
console.log("Type of data:"+ typeof(num));

//3. boolean
let l=true;
console.log("Type of data:"+ typeof(l));

//4. undefined (when no walue is stored in the variable, where undefined
// will not assigned any memory)
let un;
console.log("Type of data:"+ typeof(un));


//null(It will take some memory)
let val=null;
console.log("Type of data:"+ typeof(val));



//********************************************************************************** */

// Changes made in obj1 variable can effect to other as the 0bj1 which 
// is been created with the reference of obj2
//Non-Premitive datataype
let obj1={name: "abc"};
let obj2=obj1;
console.log(obj1.name);
console.log(obj2.name);
obj2.name="xyz";
console.log(obj1.name);
console.log(obj2.name);

//Non-Premitive datatypes
//1. array
let array=[1,2,3];
console.log("Datatype:"+ array);

//2. object

//3. function