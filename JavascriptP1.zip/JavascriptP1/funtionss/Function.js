//1. Normal function & parameterized function

function printName(name,age) {
    console.log(`My name is ${name}`);   
    console.log(`and my age is ${age}`);
    
}
printName("Tanuja",24);

//evenodd
function evenOdd(num) {
    if(num%2==0) {
        console.log(`${num} is even number`);
        return num+" is even number";
    }
        
    else {
        console.log(`${num} is not an even number`);
        return num+" is even number";;
    }
        
}
console.log(evenOdd(12));

/*evenOdd(11);

//2.Function expression
let f1=function() {
    console.log("Hello world");  
}
f1();
console.log(f1);
;

let f2=function(a,b) {
    //console.log("Addition:"+(a+b));
    return a+b;
}
console.log("Addition:"+ f2(1,2));

let f3=function(name,age,gender) {
    console.log(`Name: ${name} Age: ${age} Gender: ${gender}`);
}

f3("Abc",22,undefined);


let f4=function(name,age,nationality,native='Solapur') {
    console.log(`My name is ${name} I am ${age} years old I am ${nationality} and I am from ${native}`);
    console.log(arguments);
    
}
f4("Tanuja",24,"Indian");

//3. Arrow function
let val=()=>{
    console.log("Arrow function");
    
}
val();

let val1=a=> console.log(a);
val1(10);


//4.Callback function
function f(a) {
    console.log("Outter function");
    a();
}
//function calling
f(function f1() {
    console.log("Inner function");  
})

f(()=>{
    console.log("Inner Arrow function");   
});


//5. IIF (f)()
(()=>{console.log("Hi");
})();

((a,b)=>{
    console.log(`Value of a:${a} value of b:${b}`);
})(10,20)


function F1() {
    console.log("ho"); 
}
//As the function name is in Upper case, if i am calling with function name it is treated as a function, 
F1();
//But the same function if i am calling with new keyword it will think that function as a constructor and 
//the refrence variable as s variable
let ff=new F1();
ff;

console.log(sum);
var sum=(function add(a,b) {
    return a+b;
})(10,20);
//sum();
// console.log("IIF:"+sum);*/
