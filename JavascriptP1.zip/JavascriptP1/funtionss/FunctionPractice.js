/*function f1(){
    console.log("hi");
    return "GM";
}

var a=f1();
console.log(a);

var b=f1;
console.log(b());*/

(function table(a) {
    let n=1;
    while(n<11 && a>0) {
        console.log(a*n++ + " ");
    }
})(2);

