var a = 10;
aas()
//aas.b
console.log("g:"+aas.b);


function aas() {
    //var b;
    //console.log("f:"+b);
    const b=5;
    console.log("Hello");
    console.log("f:"+b);
}

//console.log(b);


console.log("g:"+aas.b);


//console.log(a);

// Here while executing the function a is overwritten by value 10