// // TypeError: display is not a function
// //console.log("Display:"+display);


// var display=function(a,b) {
//     console.log("Summmmmm:"+(a+b));
//     //return "hi";
// }
// display(1,2);

// show();
// function show(){
//     console.log("show function");
// }

// var a = 10;

// function test() {
//     console.log(a);
//     var a = 20;
// }

// test();

// const obj={
//     name: "Arjun",
//     getName: function () {
//         return this.name;
//     }
// };

// const fn = obj.getName();
// console.log(fn);
a(1,2);
var a=(v,z)=>{
    console.log(v+z);
    
}