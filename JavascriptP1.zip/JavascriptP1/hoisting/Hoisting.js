/*
var a=10;
console.log(a);*/


// console.log(b);
// let b;      // ReferenceError: Cannot access 'b' before initialization

/*//stores the method
let b=display;
b();
console.log("b:"+b);

//stores the result of the method
let c=display();
console.log("c:"+c);

function display() {
    console.log(a);
}*/

// console.log(val);   //ReferenceError: Cannot access 'val' before initialization
// const val=2;

/*console.log(v);
let v;
v="hii";
console.log(v);*/

/*let aa;
console.log(aa);

//function expression hoisting

//Here both the method declaration and variable declaration was moved at top, so to avoid the error we are 
// initializing the fun with method.
// fun = function(){
//     console.log("hi");
//     return 1+3;
// }

console.log("Stored a fucntion in it:"+fun);

var fun = function(){
    console.log("hi");
    return 1+3;
}

//hoisting with objects
console.log("Obj represents object reference:"+obj.name);  //TypeError: Cannot read properties of undefined (reading 'name')
var obj={
    name: "Tanuja",
    age: 25,
    from: "Solapur"
}
console.log(obj.name);*/

fun();
function fun() {
    console.log(a);
    var a=4;
    console.log("Hi");
}
