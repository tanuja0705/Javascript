var a = 10;

function test() {
    let a;
    console.log(a);
    //let a=10;
    //var a = 20;
}

test();