let student={
    name : "Tanuja",
    subject : "Selenium",
    year : 2026
}

for(let add1 in student) {
    console.log(add1);
}
let arr=[1,2,3,4];
for(let a in arr) {
    console.log(a.indexOf(30));
    
}