/*Properties means key and value pair. */
/*Object is nothing but the collection of properties and methods */
let obj={name:"Tanuja",
    age:25,
    native:"Solapur, Maharashtra"
};

/*-> For in is use to iterate through the properties of an object
-> It will go through keys of the object
 -> If it is used for array then it will consider index as key and in each itteration it will fetch one
 one key
 -> It works fine with both arrayes and objects
 -> Syntax: for(Key in objectRefVariable/arrayRefVariable){}
 -> It will work fine for arrays also but is not prefered bcz it will take index as keys
 -> Was released in es3 in 1999
 -> In for in if we pass obj.key (it will consider key as a variable in the object)*/
 //1. for object
 for(let key in obj){
    console.log(key); 
    //to print values
    //console.log(obj.key);   //here whatever value key is holding will be taken as string
    console.log(obj[key]); 
 }
 console.log("Name:"+obj.name);
 console.log("Age:"+obj["age"]);

 //2. for array
 let arr=['a','b','c','d'];
 for(let key in arr){
    console.log(key);
 } 

 /* For of
 -> It works only for ittrable object not for normal plain objects
 -> Itterable objects means Strings or the arrays any premitive type of data can be converted into 
 objects, so thouse will be also considered as an itterable object
 -> for-of loop will itterate through the values of the array.
 -> If we use it for object it will throw us an error that it will not support for objects
 it will only support for arrays and string 
 -> Syntax: for(value of arrayName){}
 -> was released in es6 in 2015*/
 //1. for object it will give "obj is not iterable" exception
//  for(let value of obj){
//     console.log(value);
//  }

//2. for array
for(let value of arr){
    console.log(value);
    //to print index
   
    //console.log(arr.indexOf('b'));
}
console.log("b:"+ arr.indexOf('b'));

let arr1 = ["apple", "banana", "mango"];

for (let element of arr1) {
    let index = arr1.indexOf(element);
    console.log(index, element);
}

console.log("******************************** Combination of For-in For-of ********************************");

let obj1={
    name: "a",
    age:25,
    from:"India"
}
let obj2={
    name: "b",
    age:25,
    from:"India"
}
let obj3={
    name: "c",
    age:24,
    from:"India"
}
let arrObj=[obj1,obj2,obj3];
for(let arr of arrObj) {
    console.log(arr);
    let temp=arr;
    for(let val in temp) {
        console.log(val+":"+temp[val]); 
    }
}