let num=0;
for(let a=0;a<5;a++){
   num+=a;
   console.log("Hello from "+a);    
}
console.log("Sum:"+num);