let i=1;
let sum=0;

// while(i<=10){
//     sum+=i;
//     console.log(i);
//     i++;
// }/

do {
    sum+=1;
    console.log(i);
    i++;
} while(i<10)
console.log("Sum:"+sum);
