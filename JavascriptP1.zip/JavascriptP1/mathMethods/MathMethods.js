//1. max(): Here it will give the maximum number out of the given values
// If we are passing the values which can't be converted into numbers(eg, array) then it will return NaN(Not a number)
// If we are not passing any value in it, it will give a -infinity 

let max=Math.max(12,'1123',1,134);
console.log("max:"+max);

//2. abs(val): it stands for absulute value(absulute value means the distance between the given number and zero)
console.log("Absulute value:"+Math.abs(8));


//3. round(value): We will round of the num
// ber which we will pass
console.log("Round for negative number rounddown:"+Math.round(-0.2));
console.log("Round for positive number roundup:"+Math.round(3.5));

//4. floor(value): it will round down the number for both - & +, eg: if it is 2.9 it return 2, if it is 2.4
// it returns 2 for negative it will work lije if -2.4 is given it will return -3 if -2.7 is given it will,
// return -3 it will ignore the decimal value
console.log("Floor for positive:"+ Math.floor(3.8));
console.log("Floor for negative:"+Math.floor(-2.4));
console.log("Floor for positive:"+ Math.floor(4.7));
console.log("Floor for negative:"+Math.floor(4.4));

//5. ceil(value): unlike round method it will ceil up/round up the number for both - & +, eg: if it is 2.9 it return 3, 
// if it is 2.4it returns 3  for negative it will work lije if -2.4 is given it will return -2 if -2.7 is 
// given it will, return -2 it will ignore the decimal value
console.log("Ceil for positive:"+ Math.ceil(3.8));
console.log("Ceil for negative:"+Math.ceil(-2.4));
console.log("Ceil for positive:"+ Math.ceil(4.7));
console.log("Ceil for negative:"+Math.ceil(4.4));

//6. sqrt(value): returns the square root of given number
console.log("squar root of 4:"+ Math.sqrt(25));
console.log("squar root of -5:"+ Math.sqrt(-5));

//7. random(): it will generate a random number between 0-1 
console.log("random:"+Math.random());
// if we want to increase like 0-6 then we will use, here it will exclude the 6 so if we want to include it
//we will add one to it
let a=Math.floor(Math.random()*6)+1;
console.log(a);


//customized range 2-20
let val=Math.floor(Math.random()*(20-2))+2
console.log(val);

//function to customize the range for random
function generateRandomNumber(max, min) {
    return Math.floor(Math.random()*(max-min))+1;
}

console.log("Random function:"+generateRandomNumber(21,1));
