class Emp{
    constructor(name, designation, joiningDate, degree,add) {
        this.name = name;
        this.designation = designation;
        this.joiningDate = joiningDate;
        this.degree = degree;
        this.add=function(add) {
            console.log(add); 
        }
    }

    info() {
        console.log("Name of emp "+this.name+" has "+this.degree+" degree and joined this company on "+this.joiningDate+" and there designation is "+this.designation+" Address ");
        this.add();    
    }
}

let e1 = new Emp("Arjun","B.Tech","12-03-2024","Automation Engineer","sjj");
e1.info();