// Contructor: it's a special method for defining the properties and methods of objects
// Make sure the 1st alphabet of the constructor name should be capital

function Student(name, age, standard, favSubject,marks) {
    this.name=name;
    this.age=age;
    this.standard=standard;
    this.favSubject=favSubject;
    this.marks=marks
    this.pass=function percent() {
        if(marks<30) {
            console.log(`${name} is Fail`);
        }
        else {
            console.log(`${name} is Pass`);
        }
            
    }
}

let student1 = new Student("Shivam", 10, 4, "Hindi",20);
console.log(student1);
student1.pass();
student1.dob="03-08-2000";
console.log(student1.dob);

let student2 = new Student("Shrutishna",12,6,"Maths",60);
console.log(student2);
student2.pass();
student2.dob="08-03-2001";
console.log(student2.dob);

