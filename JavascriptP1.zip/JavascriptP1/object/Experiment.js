const obj = {
    name: "JS",
    print: function () {
        console.log(this.name);
        return this.name;
    }
};

//console.log(obj.name);
const fn=obj.print;
fn();
console.log(NaN == NaN);
// console.log({} === {});
// console.log([] === []);0