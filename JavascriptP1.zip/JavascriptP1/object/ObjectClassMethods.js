let candidate={
    name:"Ahemad",
    age:28,
    degree: "BE",
    branch: "Computer Science",
    yop: 2018,
    designation: "Automation Engineer",
    info: function () {
        console.log("Name:"+candidate.name+" Age:"+candidate.age+" Degree:"+candidate.degree+" Branch:"+candidate.branch+" Year of passout:"+candidate.yop+" Designation:"+candidate.designation);
    },
    //object inside an object
    obj: {
        Married:"No",
        State: "Kolkata"
    }
}

/*//To print all the keys
console.log(Object.keys(candidate));

//To print the values
console.log(Object.values(candidate));

//TO print both keys n values
console.log(Object.entries(candidate));*/

//itterating between the properties of object for printing keys
for(let key in candidate) {
    console.log(key);
}

//itterating between the properties of object for printing values
for(let value in candidate) {
    console.log(candidate[value]);
}
