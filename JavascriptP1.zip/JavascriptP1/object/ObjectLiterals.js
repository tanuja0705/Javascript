let candidate={
    name:"Ahemad",
    age:28,
    degree: "BE",
    branch: "Computer Science",
    yop: 2018,
    designation: "Automation Engineer",
    info: function () {
        console.log("Name:"+candidate.name+" Age:"+candidate.age+" Degree:"+candidate.degree+" Branch:"+candidate.branch+" Year of passout:"+candidate.yop+" Designation:"+candidate.designation);
    },
    //object inside an object
    obj: {
        Married:"No",
        State: "Kolkata"
    }
}
candidate.info();
candidate.age=29;
candidate.info();

//Adding new element in the object
candidate.Currently_Working="Yes";
console.log(candidate.Currently_Working);

//deleteing an element from object
delete candidate.yop;
candidate.info();

//console.log("Name:"+candidate.name+" Age:"+candidate.age+" Degree:"+candidate.degree+" Branch:"+candidate.branch+" Year of passout:"+candidate.yop+" Designation:"+candidate.designation);
console.log("Married:"+candidate["obj"]["Married"]+" State:"+candidate.obj["State"]);