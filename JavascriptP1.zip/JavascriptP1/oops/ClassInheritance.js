class Movie {
    static from="Tamil";
    naam="With Love";
    joner="RomCom";
    mLead="Abhishan Jeevinth";
    fLead="Anaswara Rajan"

    static aboutMovie() {
        console.log("It's a romcom movie, where the mainleads are goind to find there unfinished love and explain them about there unsaid feelings"); 
    }

    movieInfo() {
        console.log(`Movie Name:${this.naam} Joner: ${this.joner} Male Lead: ${this.mLead} Female Lead:${this.fLead}`);
    }
}

class series extends Movie {
    //method overriding
    static from="Korean";
    naam="Made in Korea";
    joner="RomCom";
    mLead="Baek Hye-Jin";
    fLead="Priyanka Arulmohan"

     movieInfo() {
        console.log(`Movie Name: ${this.naam} Joner: ${this.joner} Male Lead: ${this.mLead} Female Lead:${this.fLead}`);
    }
    display() {
        console.log("sdfgh");
    }
}
series.aboutMovie();

let a = new Movie();
// Here no upcasting is done, it is just reassigning the  variable
a = new series();
a.movieInfo();
a.display();
console.log("Parent:"+Movie.from+" Child:"+series.from);
