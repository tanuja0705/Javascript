class Gmail {
    #emailId="";
    #pwd="";
    constructor(em,p) {
        this.#emailId=em;
        this.#pwd=p;
    }

    setEmail(email,pwd,nemail) {
        if(this.#emailId===email && this.#pwd===pwd)
            this.#emailId=nemail;
        else
            console.log("Invalid credentials");
    }

    setPwd(email,pwd,npwd) {
        if(this.#emailId===email && this.#pwd===pwd)
            this.#pwd=npwd;
        else
            console.log("Invalid credentials");
    }

    getEmail() {
            return this.#emailId;
    }

    getPwd() {
            return this.#pwd;
    }
}
let obj= new Gmail("as12@gmail.com","Abc123");
console.log("Email:"+ obj.getEmail()+" Pwd:"+obj.getPwd());
obj.setEmail("as1@gmail.com","Abc123",'as123@gmail.com');
console.log("Email:"+ obj.getEmail());