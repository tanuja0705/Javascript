class Animal {
    sound() {
        console.log("Animal sound");
    }
}

class Dog extends Animal {
    sound() {
        console.log("Bark");
    }
}

class Cat extends Animal {
    sound() {
        console.log("Meow");
    }
}

let animal;

animal = new Dog();
animal.sound();

animal = new Cat();
animal.sound();