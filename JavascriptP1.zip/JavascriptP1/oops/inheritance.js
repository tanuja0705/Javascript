//1. Object inheritance
let starr= {
    name: {
        fname: "",
        mname: "",
        lname: ""
    },
    dob: '',
    age: 0,
    education: "",
    sibings:0,
    married:false
}

let rich = Object.create(starr);
rich.name.fname="Richa";
rich.name.mname="Ravindra";
rich.name.lname="Kulkarni";
rich.dob='16-05-2000';
rich.age=25;
rich.education="MSC";
rich.siblings=1;
rich.married=false;
console.log("Fullname:"+ rich.name.fname+" "+rich.name.mname+" "+rich.name.lname+" Age:"+rich.age+" DOB:"+rich.dob+
    " Education:"+rich.education+" Siblings:"+rich.siblings+" Merried:"+rich.married);

