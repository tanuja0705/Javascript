//1. arithmatic operator
//normal addition and storing in a variable and printing
a=3+5
// to print the statement we use console.log() in js
console.log("Addition:"+a);

//incrementing and printing
a++;
console.log("incrementing:"+a);

//decrement and printing
a--;
console.log("decrement:"+a);

//%
modulas=4%a;
console.log("modulas:"+modulas);


//2. comparision/relational operator(==,===,!=,>,<,>=,<=)

console.log(4<2);

// == will only compare the value
ele1=2;
ele2="2";
console.log(typeof ele1)
console.log("working of ==:"+ (ele1==ele2));
//=== will compare values and datatype both
console.log(typeof ele2)
console.log("working of ====:"+ (ele1===ele2))

//3. Assignment Operators (=,+=,-=,*=,/=,%=)
val1=10
val2=20
val3=val1+val2;
console.log(val3);
val2-=val1;
console.log(val2);