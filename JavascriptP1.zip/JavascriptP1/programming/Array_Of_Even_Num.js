//Write a javascript function that takes an array of numbers and returns a new array with only the even numbers.
let arr=[17,25,34,48,50,62];
let even =[];
for(let val in arr) {
    if(arr[val]%2==0) {
        even.push(arr[val])
    }
    else
        continue;
}
console.log("even:"+ even);
