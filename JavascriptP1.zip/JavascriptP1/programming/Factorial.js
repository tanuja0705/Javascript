//6. Write a javascript program to calculate the factorial of a given number.
let f=(num)=>{
let fact=1;
for(let i=1;i<=num;i++) {
    fact*=i;
}
}
let val=7
console.log("Factorial of "+val+" is "+fact);
//[[]]