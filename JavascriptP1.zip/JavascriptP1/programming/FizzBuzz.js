//Print numbers from 1 to 50
/*Rules:
Multiple of 3 → Fizz
Multiple of 5 → Buzz
Multiple of 3 and 5 → FizzBuzz

Example:
3 → Fizz
5 → Buzz
15 → FizzBuzz*/
let min=1;
let max=50;
for(let i=min;i<=max;i++) {
    if(i%3==0)
        console.log(i+" is Fizz");
    else if(i%5==0)
        console.log(i+" is Buzz");
    else if(i%3==0 && i%5==0)
        console.log(i+" is FizzBuzz");
}