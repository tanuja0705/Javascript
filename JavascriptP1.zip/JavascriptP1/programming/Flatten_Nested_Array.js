let arr=[1, [2,3], [4,[5]]];
let arr1=[];
function fun(ele) {
    for(let i=0;i<ele.length;i++) {
        
    }
}