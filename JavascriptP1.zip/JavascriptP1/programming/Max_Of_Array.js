//Write a javascript program to find the maximum number in an array.

arr=[32333,32,122,1234,13];
max=arr[0];
for(let i=1;i<arr.length;i++) {
    if(arr[i]>max)
        max=arr[i];
    else
        continue;
}
console.log("Max value in "+arr+" is "+max);
