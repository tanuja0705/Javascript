//Write a javascript function to check if a given string is a palindrome (reads the same forwards and backwards).
let str="momo";
let str1=str.split('').reverse().join('');
// for(i=str.length-1;i>=0;i--) {
//     str1+=str.charAt(i);
// }
str==str1?console.log(str+" is palindrome"):console.log(str+" is not palindorme");