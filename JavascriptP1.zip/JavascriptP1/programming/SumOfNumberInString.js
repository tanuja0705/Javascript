let str = "asb40][#$500jhfkwj2000"
let num=0;
let temp=0;
for(let i=0;i<str.length;i++) {
    if(str.charAt(i)>=48 || str.charAt(i)<=57) {
        temp=Number(str.charAt(i))+(temp*10)
    }
    else{
        num+=temp;
        temp=0;
    }
}
num+=temp;
console.log(num);


console.log(str.split(/\D/).reduce((a, cv)=>{if(cv){a+=Number(cv)}return a},0))