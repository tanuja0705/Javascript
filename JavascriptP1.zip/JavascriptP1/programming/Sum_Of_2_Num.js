//1. Write a javascript function to calculate the sum of two numbers.

let sum=(a,b)=>a+b;

console.log(sum(10,20));
console.log(sum(2.4,4.9));