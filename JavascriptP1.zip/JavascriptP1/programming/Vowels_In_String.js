//Count Vowels in a String
let str = "Happy";
let ct=0;
for(let a=0;a<str.length;a++) {
    if(str.charAt(a)=='a' || str.charAt(a)=='e' || str.charAt(a)=='i' || str.charAt(a)=='o' || str.charAt(a)=='u')
        ct++;
}
console.log("Number of vowels in "+str+" are "+ct);