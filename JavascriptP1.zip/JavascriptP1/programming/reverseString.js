//Write a javascript program to reverse a given string.
let str="tanuja";
console.log("Original string:"+str);
console.log("Reversed string:"+ str.split('').reverse().join(''));