// var a;
// function f(num) {
//     a=num;
// }
// console.log(a);
// f(10);
// console.log(a);

// console.log("Var:"+v);      //output:undefined
// var v
// console.log("Var:"+v);      //output: Error

// console.log("Let:"+l);
// let l;
// console.log("Let:"+l);

// console.log("Const:"+c);    //output: Error
// const c=6;
// console.log("Const:"+c);
// c=7;
// console.log("Constttttttt:"+c);    //output: Error


function fun(val) {
    console.log("I am playing "+val);
    console.log(`I am playing ${val}`);
    
}
fun("Cricket")
fun("Football")