// In js to declare a variable we use 3 keywords let,var,const
// syntax let/var/const variableName = value;

/*
-> when js was introduced only one keyword was there that is var
-> it is having global scope & function scope
-> If it is created in a block then it can be used anywhere in the script
-> Here declaration & initialization if we redeclare the same variable 
and reinitialize it, it will take updated value
*/ 
console.log("/************************Type of Variables **************************/");

var num=12.23;
console.log("Num:"+ typeof(num));
console.log(num);


var vv=10
var vv
console.log(vv);

var vv1=20;
var vv2=30;
console.log(vv2);



/*
-> let and const are block scoped, which means if they are declared in 
a block they can't be used outside.
-> But if they are global they can be used within the script
-> let & const are released in ecma6
-> With let we can re-initialize but can't re-declare
-> For const we can't even re-declare or re-initialize the variable
*/
let name="Tanuja";
console.log(name);

let n="Sonawale";
//let n (giving exception)
console.log("Original:"+n);

n= "Nagnath Sonawale"
console.log("Reinitialized:"+ n);


/*for const variable declaration and initialization in mandetory in single
 line or it will give 'const' declarations must be initialized. or 
 Missing initializer in const declaration. exception*/
const age=25;
console.log(age);

const dob="08-03-2001";
console.log("original DOB:"+dob);
/*const dob ('const' declarations must be initialized.ts(1155)
Cannot redeclare block-scoped variable 'dob')*/

//dob=" N Sonawale"; (Assignment to constant variable runtime exception)



/************************Scope of Variables **************************/
console.log("/************************Scope of Variables **************************/");
//1. if all the variables are created globally scope is in the entire script
let v1=123.56;
var v2="abc";
const v3=true;
{
    console.log(v1);
    console.log(v2);
    console.log(v3);
}

/* 2. if the variables are declared & initialized within the block only 
var is accessable outside the block n for let & onst variable it will 
give "val2 is not defined" exception*/
{
    var val1=445;
    let val2=true;
    const val3="xyz";
}
console.log(val1);
//console.log(val2);
//console.log(val3);

/*3. function accessing global variable */
function f1() {
    console.log(v1);
    console.log(v2);
    console.log(v3);
}
f1();

/*4. Declaration, initialization n utilization in fuction block only */
function f2() {
    let v1=34;
    var v2="gjhgh";
    const v3=true;

    console.log(v1);
    console.log(v2);
    console.log(v3);
}
f2();

/*5. Declaration & initialization in function & utilization outside the 
function all the 3 type of variables if they are declared n initialized
in function can't be used outside it*/
function f3() {
    let value1=25;
    var value2="Tanuja";
    const value3=true;
}
f3()
    console.log(value1);
    console.log(value2);
    console.log(value3);


/*If the variable name are same but type is different it will give exception 
for*/